G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.3*
G04 #@! TF.CreationDate,2026-04-05T16:25:52+01:00*
G04 #@! TF.ProjectId,hs,68732e6b-6963-4616-945f-706362585858,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.3) date 2026-04-05 16:25:52*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.262500X-0.275000X-0.262500X0.275000X-0.262500X0.275000X0.262500X-0.275000X0.262500X0*%
%ADD11RoundRect,0.050000X-1.250000X-1.500000X1.250000X-1.500000X1.250000X1.500000X-1.250000X1.500000X0*%
%ADD12RoundRect,0.262500X0.325000X0.262500X-0.325000X0.262500X-0.325000X-0.262500X0.325000X-0.262500X0*%
%ADD13RoundRect,0.175000X0.175000X-0.537500X0.175000X0.537500X-0.175000X0.537500X-0.175000X-0.537500X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,R1*
X147042500Y-31115000D03*
X148867500Y-31115000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X146000000Y-28451000D03*
X150000000Y-28451000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,C1*
X148817500Y-37465000D03*
X147092500Y-37465000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,U1*
X147005000Y-35427500D03*
X147955000Y-35427500D03*
X148905000Y-35427500D03*
X148905000Y-33152500D03*
X147005000Y-33152500D03*
G04 #@! TD*
M02*
